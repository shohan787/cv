CREATE DATABASE IF NOT EXISTS bikedoll_reseller CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bikedoll_reseller;

CREATE TABLE admins (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(190) UNIQUE NOT NULL,
 password VARCHAR(255) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE resellers (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 phone VARCHAR(30) NOT NULL UNIQUE,
 whatsapp VARCHAR(30),
 email VARCHAR(190),
 nid_number VARCHAR(80),
 address TEXT,
 district VARCHAR(80),
 upazila VARCHAR(80),
 facebook VARCHAR(255),
 payment_method ENUM('bkash','nagad','bank') DEFAULT 'bkash',
 payment_number VARCHAR(80),
 nid_front VARCHAR(255),
 nid_back VARCHAR(255),
 profile_photo VARCHAR(255),
 password VARCHAR(255) NOT NULL,
 status ENUM('pending','active','suspended','rejected') DEFAULT 'pending',
 balance DECIMAL(12,2) DEFAULT 0,
 total_profit DECIMAL(12,2) DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE products (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(180) NOT NULL,
 sku VARCHAR(80) UNIQUE,
 description TEXT,
 image VARCHAR(255),
 reseller_price DECIMAL(12,2) NOT NULL,
 suggested_price DECIMAL(12,2) NOT NULL,
 stock INT DEFAULT 0,
 status TINYINT(1) DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE orders (
 id INT AUTO_INCREMENT PRIMARY KEY,
 reseller_id INT NOT NULL,
 customer_name VARCHAR(120) NOT NULL,
 customer_phone VARCHAR(30) NOT NULL,
 customer_address TEXT NOT NULL,
 product_id INT NOT NULL,
 quantity INT NOT NULL DEFAULT 1,
 selling_price DECIMAL(12,2) NOT NULL,
 delivery_charge DECIMAL(12,2) DEFAULT 0,
 reseller_profit DECIMAL(12,2) DEFAULT 0,
 status ENUM('pending','confirmed','processing','shipped','delivered','cancelled','returned') DEFAULT 'pending',
 note TEXT,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(reseller_id) REFERENCES resellers(id),
 FOREIGN KEY(product_id) REFERENCES products(id)
);

CREATE TABLE withdrawals (
 id INT AUTO_INCREMENT PRIMARY KEY,
 reseller_id INT NOT NULL,
 method VARCHAR(30) NOT NULL,
 account_number VARCHAR(80) NOT NULL,
 amount DECIMAL(12,2) NOT NULL,
 status ENUM('pending','approved','rejected') DEFAULT 'pending',
 note TEXT,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(reseller_id) REFERENCES resellers(id)
);

CREATE TABLE documents (
 id INT AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(180) NOT NULL,
 description TEXT,
 file_path VARCHAR(255) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE notices (
 id INT AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(180) NOT NULL,
 body TEXT NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO admins(name,email,password) VALUES
('BiKe Doll BD Admin','admin@bikedollbd.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC1Z4fWwW0a8hQYhQyK');

INSERT INTO products(name,sku,description,reseller_price,suggested_price,stock) VALUES
('Motorcycle Viral Engine Light','BD-001','12–24V waterproof motorcycle engine light.',300,450,100);
