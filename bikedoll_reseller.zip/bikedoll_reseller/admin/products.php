<?php
require '../config.php';
require_admin();

$err = '';
$ok = '';

if($_SERVER['REQUEST_METHOD']==='POST'){
    try {
        verify_csrf();

        $name = trim($_POST['name'] ?? '');
        $sku = trim($_POST['sku'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $reseller_price = (float)($_POST['reseller_price'] ?? 0);
        $suggested_price = (float)($_POST['suggested_price'] ?? 0);
        $stock = (int)($_POST['stock'] ?? 0);
        $status = isset($_POST['status']) ? 1 : 0;
        $imagePath = '';

        if ($name === '' || $reseller_price <= 0 || $suggested_price <= 0) {
            throw new Exception('Product name এবং price সঠিকভাবে দিন।');
        }

        if ($sku === '') $sku = null;

        // Product image upload
        if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] !== UPLOAD_ERR_NO_FILE) {
            $file = $_FILES['product_image'];
            if ($file['error'] !== UPLOAD_ERR_OK) {
                throw new Exception('ছবি upload করা যায়নি। আবার চেষ্টা করুন।');
            }
            if ($file['size'] > 5 * 1024 * 1024) {
                throw new Exception('ছবির size সর্বোচ্চ 5MB হতে পারবে।');
            }

            $allowed = [
                'image/jpeg' => 'jpg',
                'image/png'  => 'png',
                'image/webp' => 'webp',
                'image/gif'  => 'gif'
            ];
            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
            if (!isset($allowed[$mime])) {
                throw new Exception('শুধু JPG, PNG, WEBP বা GIF image ব্যবহার করুন।');
            }

            $uploadDir = dirname(__DIR__) . '/uploads/products';
            if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true)) {
                throw new Exception('uploads/products folder তৈরি করা যায়নি।');
            }

            $filename = 'product_' . date('Ymd_His') . '_' . bin2hex(random_bytes(5)) . '.' . $allowed[$mime];
            $target = $uploadDir . '/' . $filename;
            if (!move_uploaded_file($file['tmp_name'], $target)) {
                throw new Exception('ছবিটি server-এ save করা যায়নি।');
            }
            $imagePath = 'uploads/products/' . $filename;
        }

        $s = db()->prepare(
            "INSERT INTO products(name,sku,description,image,reseller_price,suggested_price,stock,status)
             VALUES(?,?,?,?,?,?,?,?)"
        );
        $s->execute([$name,$sku,$description,$imagePath,$reseller_price,$suggested_price,$stock,$status]);
        $ok = 'Product সফলভাবে add হয়েছে।';
    } catch (Throwable $e) {
        $err = $e->getMessage();
    }
}

$rows = db()->query("SELECT * FROM products ORDER BY id DESC")->fetchAll();
?>
<!doctype html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Products - <?=e(SITE_NAME)?></title>
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="layout">
<aside class="sidebar">
<h2>🏍️ <?=e(SITE_NAME)?></h2>
<a href="index.php">📊 Dashboard</a>
<a href="resellers.php">👥 Resellers</a>
<a href="products.php">🛍️ Products</a>
<a href="orders.php">📦 Orders</a>
<a href="withdrawals.php">💰 Withdrawals</a>
<a href="documents.php">📄 Documents</a>
<a href="notices.php">📢 Notices</a>
</aside>

<main class="content">
<div class="panel form">
<h2>🛍️ Add New Product</h2>
<p style="color:var(--muted);margin-top:-5px">প্রতিটি product-এর জন্য এখন সরাসরি image upload করা যাবে।</p>
<?php if($err): ?><div class="alert"><?=e($err)?></div><?php endif; ?>
<?php if($ok): ?><div class="alert ok"><?=e($ok)?></div><?php endif; ?>

<form method="post" enctype="multipart/form-data">
<?=csrf_field()?>
<input class="input" name="name" placeholder="Product name" required>
<input class="input" name="sku" placeholder="SKU">

<div class="upload-box">
<label for="product_image">📷 Product Image *</label>
<input class="input" id="product_image" type="file" name="product_image" accept="image/jpeg,image/png,image/webp,image/gif" required>
<small style="color:var(--muted)">JPG / PNG / WEBP / GIF • সর্বোচ্চ 5MB</small>
<img id="imagePreview" class="upload-preview" alt="Image preview">
</div>

<textarea name="description" placeholder="Product description"></textarea>
<input class="input" type="number" step=".01" min="0.01" name="reseller_price" placeholder="Reseller price" required>
<input class="input" type="number" step=".01" min="0.01" name="suggested_price" placeholder="Suggested selling price" required>
<input class="input" type="number" min="0" name="stock" placeholder="Stock" value="0">
<label class="label"><input type="checkbox" name="status" checked> Active product</label>
<br><br>
<button class="btn" type="submit">➕ Add Product</button>
</form>
</div>

<div class="panel" style="margin-top:20px;overflow:auto">
<h2>Product List</h2>
<table class="table">
<tr><th>Image</th><th>Name</th><th>Reseller</th><th>Suggested</th><th>Stock</th><th>Status</th></tr>
<?php foreach($rows as $p): ?>
<tr>
<td>
<?php if(!empty($p['image'])): ?>
<img class="product-thumb" src="../<?=e($p['image'])?>" alt="<?=e($p['name'])?>">
<?php else: ?><div class="empty-image">No Image</div><?php endif; ?>
</td>
<td><?=e($p['name'])?></td>
<td><?=CURRENCY.number_format((float)$p['reseller_price'],2)?></td>
<td><?=CURRENCY.number_format((float)$p['suggested_price'],2)?></td>
<td><?=e($p['stock'])?></td>
<td><?=$p['status'] ? '<span class="success">● Active</span>' : '<span class="danger">● Inactive</span>'?></td>
</tr>
<?php endforeach; ?>
<?php if(!$rows): ?><tr><td colspan="6">এখনো কোনো product নেই।</td></tr><?php endif; ?>
</table>
</div>
</main>
</div>
<script>
document.getElementById('product_image').addEventListener('change', function(){
  const file=this.files[0], preview=document.getElementById('imagePreview');
  if(!file){preview.style.display='none';return;}
  preview.src=URL.createObjectURL(file); preview.style.display='block';
});
</script>
</body>
</html>
