<?php
require '../config.php';
require_admin();

try {
    $cols = db()->query("SHOW COLUMNS FROM resellers")->fetchAll();
} catch(Throwable $e) {
    exit('<pre>'.e($e->getMessage()).'</pre>');
}
?>
<!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>DB Check</title><link rel="stylesheet" href="../assets/style.css"></head>
<body><div class="container"><div class="panel">
<h2>Resellers Database Check</h2>
<p>Registration সমস্যার জন্য আপনার বর্তমান <b>resellers</b> table-এর columns:</p>
<table class="table"><tr><th>Column</th><th>Type</th><th>Null</th><th>Default</th></tr>
<?php foreach($cols as $c): ?><tr><td><?=e($c['Field'])?></td><td><?=e($c['Type'])?></td><td><?=e($c['Null'])?></td><td><?=e((string)$c['Default'])?></td></tr><?php endforeach; ?>
</table>
</div></div></body></html>