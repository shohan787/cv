USE bikedoll_reseller;

-- Run these only if your existing products table does not already have these columns.
-- If the columns already exist, skip those ALTER lines.
ALTER TABLE products ADD COLUMN image VARCHAR(255) NULL AFTER description;
ALTER TABLE products ADD COLUMN status TINYINT(1) NOT NULL DEFAULT 1 AFTER stock;

-- Make sure the demo product is active.
UPDATE products SET status=1 WHERE sku='BD-001';

-- If the demo product is missing, insert it.
INSERT INTO products(name,sku,description,image,reseller_price,suggested_price,stock,status)
SELECT 'Motorcycle Viral Engine Light','BD-001',
       '12–24V waterproof motorcycle engine light.',
       NULL,300,450,100,1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE sku='BD-001');
