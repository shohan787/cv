<?php
session_start();

define('DB_HOST', 'localhost');
define('DB_NAME', 'shfun1_bikedoll');
define('DB_USER', 'shfun1_bikedoll');
define('DB_PASS', 'shfun1_bikedoll');
define('SITE_NAME', 'BiKe Doll BD');
define('CURRENCY', '৳');

function db() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4",
                DB_USER, DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
        } catch (PDOException $e) {
            http_response_code(500);
            exit('<div style="font-family:Arial;padding:20px"><h3>Database connection error</h3><p>config.php-তে DB_HOST, DB_NAME, DB_USER, DB_PASS ঠিক আছে কিনা দেখুন।</p><small>'.htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8').'</small></div>');
        }
    }
    return $pdo;
}
function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function redirect($url){ header("Location: $url"); exit; }
function reseller(){ return $_SESSION['reseller'] ?? null; }
function admin(){ return $_SESSION['admin'] ?? null; }
function require_reseller(){ if (!reseller()) redirect('../login.php'); }
function require_admin(){ if (!admin()) redirect('login.php'); }
function flash($key,$msg){ $_SESSION['flash'][$key]=$msg; }
function get_flash($key){ $m=$_SESSION['flash'][$key]??null; unset($_SESSION['flash'][$key]); return $m; }
function csrf_token(){ if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function csrf_field(){ return '<input type="hidden" name="csrf" value="'.e(csrf_token()).'">'; }
function verify_csrf(){
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !hash_equals($_SESSION['csrf']??'', $_POST['csrf']??'')) {
        http_response_code(400);
        exit('Invalid request.');
    }
}
?>