# BiKe Doll BD Reseller System

বাংলাদেশ-কেন্দ্রিক reseller management system.

## এই version-এর প্রধান সুবিধা
- Reseller registration/login
- Reseller dashboard
- Product catalogue
- Admin product management
- **Product add করার সময় বাধ্যতামূলক image upload**
- JPG / PNG / WEBP / GIF image support
- Maximum image size: 5MB
- Upload করা product image-এর live preview
- Reseller product page-এ uploaded image display
- Order management
- Earnings / withdrawal pages
- Documents / notices
- Admin dashboard
- Responsive mobile-friendly layout
- **Yellow + white modern mobile-app style theme**

## Product image upload
Admin → Products → Add New Product থেকে image select করুন।
ছবি `uploads/products/` folder-এ save হবে এবং product list ও reseller product page-এ দেখাবে।

## Setup
1. MySQL database তৈরি করুন।
2. `schema.sql` import করুন অথবা existing database হলে প্রয়োজনমতো `fix_existing_database.sql` ব্যবহার করুন।
3. `config.php`-তে DB_HOST, DB_NAME, DB_USER, DB_PASS ঠিক করুন।
4. `uploads/products/` folder server-এ writable রাখুন (সাধারণত 755 যথেষ্ট; hosting অনুযায়ী 775 লাগতে পারে)।
5. Admin login করে Products থেকে image সহ product add করুন।
