<?php
require 'config.php';

$err = '';
$old = $_POST ?? [];

function table_columns($table) {
    $stmt = db()->query("SHOW COLUMNS FROM `$table`");
    $cols = [];
    foreach ($stmt->fetchAll() as $row) $cols[] = $row['Field'];
    return $cols;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        verify_csrf();

        $name = trim($_POST['name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $pass = $_POST['password'] ?? '';

        if ($name === '') throw new Exception('নাম দিন।');
        if ($phone === '') throw new Exception('মোবাইল নম্বর দিন।');
        if (strlen($pass) < 6) throw new Exception('Password কমপক্ষে ৬ অক্ষরের হতে হবে।');

        $pdo = db();
        $cols = table_columns('resellers');

        // Find the actual phone column used by the installed database.
        $phoneCol = null;
        foreach (['phone','mobile','mobile_number','phone_number'] as $c) {
            if (in_array($c, $cols, true)) { $phoneCol = $c; break; }
        }
        if (!$phoneCol) throw new Exception('resellers table-এ phone/mobile column পাওয়া যাচ্ছে না।');

        $check = $pdo->prepare("SELECT id FROM resellers WHERE `$phoneCol`=? LIMIT 1");
        $check->execute([$phone]);
        if ($check->fetch()) throw new Exception('এই মোবাইল নম্বর দিয়ে আগে থেকেই account আছে।');

        // Map form fields to whatever columns actually exist.
        $data = [];
        $map = [
            'name' => $name,
            'phone' => $phone,
            'mobile' => $phone,
            'mobile_number' => $phone,
            'phone_number' => $phone,
            'whatsapp' => trim($_POST['whatsapp'] ?? ''),
            'email' => trim($_POST['email'] ?? ''),
            'nid_number' => trim($_POST['nid_number'] ?? ''),
            'nid' => trim($_POST['nid_number'] ?? ''),
            'address' => trim($_POST['address'] ?? ''),
            'district' => trim($_POST['district'] ?? ''),
            'upazila' => trim($_POST['upazila'] ?? ''),
            'facebook' => trim($_POST['facebook'] ?? ''),
            'payment_method' => $_POST['payment_method'] ?? 'bkash',
            'payment_number' => trim($_POST['payment_number'] ?? ''),
            'password' => password_hash($pass, PASSWORD_DEFAULT),
            'status' => 'pending',
            'is_approved' => 0,
            'approved' => 0,
            'created_at' => date('Y-m-d H:i:s')
        ];

        foreach ($map as $column => $value) {
            if (in_array($column, $cols, true)) $data[$column] = $value;
        }

        // Common required defaults.
        foreach (['name','password'] as $required) {
            if (!array_key_exists($required, $data)) {
                throw new Exception("Database-এর resellers table-এ `$required` column পাওয়া যাচ্ছে না।");
            }
        }

        $columns = array_keys($data);
        $quoted = array_map(fn($c) => "`$c`", $columns);
        $marks = implode(',', array_fill(0, count($columns), '?'));

        $sql = "INSERT INTO `resellers` (".implode(',', $quoted).") VALUES ($marks)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(array_values($data));

        flash('ok', 'রেজিস্ট্রেশন সফল হয়েছে। Admin approval-এর পর login করতে পারবেন।');
        redirect('login.php');

    } catch (Throwable $e) {
        $err = $e->getMessage();
    }
}
?>
<!doctype html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Reseller Registration</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="nav">
  <div class="brand">🏍️ <?=SITE_NAME?></div>
  <a href="index.php">Home</a>
</header>

<div class="container">
  <div class="panel form">
    <h2>Reseller Registration</h2>

    <?php if($err): ?>
      <div class="alert"><?=e($err)?></div>
    <?php endif; ?>

    <form method="post" action="register.php" autocomplete="on">
      <?=csrf_field()?>

      <label class="label">পূর্ণ নাম *</label>
      <input class="input" name="name" value="<?=e($old['name'] ?? '')?>" required>

      <label class="label">মোবাইল *</label>
      <input class="input" name="phone" value="<?=e($old['phone'] ?? '')?>" required>

      <label class="label">WhatsApp</label>
      <input class="input" name="whatsapp" value="<?=e($old['whatsapp'] ?? '')?>">

      <label class="label">Email</label>
      <input class="input" type="email" name="email" value="<?=e($old['email'] ?? '')?>">

      <label class="label">NID নম্বর</label>
      <input class="input" name="nid_number" value="<?=e($old['nid_number'] ?? '')?>">

      <label class="label">জেলা</label>
      <input class="input" name="district" value="<?=e($old['district'] ?? '')?>">

      <label class="label">উপজেলা</label>
      <input class="input" name="upazila" value="<?=e($old['upazila'] ?? '')?>">

      <label class="label">পূর্ণ ঠিকানা</label>
      <textarea name="address"><?=e($old['address'] ?? '')?></textarea>

      <label class="label">Facebook Page/Profile</label>
      <input class="input" name="facebook" value="<?=e($old['facebook'] ?? '')?>">

      <label class="label">Payment Method</label>
      <select class="select" name="payment_method">
        <option value="bkash">bKash</option>
        <option value="nagad">Nagad</option>
        <option value="bank">Bank</option>
      </select>

      <label class="label">Payment Number/Account</label>
      <input class="input" name="payment_number" value="<?=e($old['payment_number'] ?? '')?>">

      <label class="label">Password *</label>
      <input class="input" type="password" name="password" minlength="6" required>

      <button class="btn" type="submit">Submit Registration</button>
    </form>
  </div>
</div>
</body>
</html>