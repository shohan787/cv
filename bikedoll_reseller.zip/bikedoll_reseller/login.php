<?php require 'config.php';
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf();$stmt=db()->prepare("SELECT * FROM resellers WHERE phone=? LIMIT 1");$stmt->execute([$_POST['phone']]);$u=$stmt->fetch();
if($u && password_verify($_POST['password'],$u['password'])){
if($u['status']==='active'){$_SESSION['reseller']=$u;redirect('reseller/index.php');}
else $err='আপনার account এখন '.$u['status'].' অবস্থায় আছে।';
}else $err='মোবাইল অথবা password ভুল।';}
?>
<!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Login</title><link rel="stylesheet" href="assets/style.css"></head><body><div class="container"><div class="panel form"><h2>Reseller Login</h2><?php if(isset($err)):?><div class="alert"><?=$err?></div><?php endif;?><?php if($m=get_flash('ok')):?><div class="alert ok"><?=$m?></div><?php endif;?><form method="post"><?=csrf_field()?><label class="label">Mobile</label><input class="input" name="phone" required><label class="label">Password</label><input class="input" type="password" name="password" required><button class="btn">Login</button></form><p>নতুন? <a href="register.php">Register as reseller</a></p></div></div></body></html>