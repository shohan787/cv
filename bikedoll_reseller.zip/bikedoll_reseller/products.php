<?php
require 'config.php';
$products = db()->query("SELECT * FROM products WHERE status=1 ORDER BY id DESC")->fetchAll();
?>
<!doctype html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Products</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="nav">
  <div class="brand">🏍️ <?=SITE_NAME?></div>
  <nav>
    <a href="index.php">Home</a>
    <a href="register.php">Join</a>
    <a href="login.php">Login</a>
  </nav>
</header>

<div class="container">
  <h2>Product Catalogue</h2>

  <?php if (!$products): ?>
    <div class="panel">
      <h3>এখনো কোনো product পাওয়া যায়নি</h3>
      <p>Admin panel → Products থেকে product add করুন এবং Status Active রাখুন।</p>
    </div>
  <?php else: ?>
    <div class="product-grid">
      <?php foreach($products as $p): ?>
        <div class="panel product">
          <?php if(!empty($p['image'])): ?>
            <img src="<?=e($p['image'])?>" alt="<?=e($p['name'])?>">
          <?php endif; ?>

          <h3><?=e($p['name'])?></h3>
          <p><?=nl2br(e($p['description']))?></p>
          <p><b>Reseller Price: <?=CURRENCY.number_format((float)$p['reseller_price'],2)?></b></p>
          <p>Suggested Price: <?=CURRENCY.number_format((float)$p['suggested_price'],2)?></p>
          <a class="btn" href="login.php">Order Now</a>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>
</body>
</html>